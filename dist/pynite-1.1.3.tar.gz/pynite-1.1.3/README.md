# pynite
WIP Asynchronous python wrapper for the Fortnite API.

#### Installation
Type this into your console:
```
pip install pynite
```
Keep in mind that this is a work in progress and will be updated continuously.
#### Bugs and Errors
If you come across an unknown error or bug, please [open an issue](https://github.com/cree-py/pynite/issues/new).
#### Documentation
Documentation is in progress! If you would like to contribute, let us know by joining our [discord server](https://discord.gg/RzsYQ9f).
#### Misc
This is an async python wrapper for the fortnite API. If you would like to help, just let us know [here](https://discord.gg/RzsYQ9f)!
