### Lifetime Stats

List\[{'key': 'statistic', 'value': 'value'}, {'key': 'statistic', 'value': 'value'}\]

Index | Key | Value |
|-----|------|------|
| 0 | top_3 | 'num' |
| 1 | top_5s | 'num' |
| 2 | top_3s | 'num' |
| 3 | top_6s | 'num' |
| 4 | top_12s | 'num' |
| 5 | top_25s | 'num' |
| 6 | score | 'num' |
| 7 | matches_played | 'num' |
| 8 | wins | 'num' |
| 9 | win% | 'num%' |
| 10 | kills | 'num' |
| 11 | k/d | 'decimal' |
| 12 | kills_per_min | 'decimal' |
| 13 | time_played | '0d 0h 0m 0s' |
| 14 | avg_survival_time | '0d 0h 0m 0s' |
